package org.nxf.frame.service;

public class PersonService extends AbstractService {

	public PersonService(String table_name, String bean_name) {
		super(table_name, bean_name);
		// TODO Auto-generated constructor stub
	}

}
