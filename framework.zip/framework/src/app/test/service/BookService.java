package app.test.service;

import org.nxf.frame.service.AbstractService;

public class BookService extends AbstractService{

	public BookService(String table_name, String bean_name) {
		super(table_name, bean_name);
		// TODO Auto-generated constructor stub
	}

}
