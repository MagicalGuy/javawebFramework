package app.test.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.nxf.frame.action.Action;
import org.nxf.frame.service.PersonService;

public class PersonAction extends Action{

	private static final long serialVersionUID = 1L;
	
	
	public PersonAction() {
		// TODO Auto-generated constructor stub
		this.setDir("jsp/person");
		this.setService(new PersonService("tbl_person","app.test.bean.Person"));
	}
	
	public void abc(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	}
};
